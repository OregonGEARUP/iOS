# gearup-ios
This repo is for the iOSapp for gear up
