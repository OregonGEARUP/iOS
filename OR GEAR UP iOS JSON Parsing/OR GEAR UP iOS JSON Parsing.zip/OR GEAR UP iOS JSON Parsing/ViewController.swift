//
//  ViewController.swift
//  OR GEAR UP iOS JSON Parsing
//
//  Created by Max MacEachern on 9/26/16.
//  Copyright © 2016 Max MacEachern. All rights reserved.
//

import UIKit



class WebViewController: UIViewController {
    var url: String!
    @IBOutlet weak var webView: UIWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let request = URLRequest(url: URL(string:self.url)!)
        self.webView.loadRequest(request)
    }
}


class ViewController: UIViewController {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var moreInfoButton: UIButton!
    @IBOutlet weak var submitButton: UIButton!
    @IBOutlet weak var PrevButton: UIButton!
    @IBOutlet weak var NextButton: UIButton!
    @IBOutlet weak var fieldLabel1: UILabel!
    @IBOutlet weak var inputField1: UITextField!
    @IBOutlet weak var fieldLabel2: UILabel!
    @IBOutlet weak var inputField2: UITextField!
    @IBOutlet weak var fieldLabel3: UILabel!
    @IBOutlet weak var inputField3: UITextField!
    @IBOutlet var radioButtons: [UIButton]!
    @IBOutlet weak var groupStackview: UIStackView!
    @IBOutlet weak var fieldStackview: UIStackView!
    @IBOutlet weak var checkboxStackview: UIStackView!
    @IBOutlet weak var radioStackview: UIStackView!
    @IBOutlet weak var fieldDateStackview: UIStackView!
    @IBOutlet weak var fieldDateLabel1: UILabel!
    @IBOutlet weak var inputDate1: UITextField!
    @IBOutlet weak var inputFieldDate1: UITextField!
    @IBOutlet weak var fieldDateLabel2: UILabel!
    @IBOutlet weak var inputFieldDate2: UITextField!
    @IBOutlet weak var inputDate2: UITextField!
    @IBOutlet weak var fieldDateLabel3: UILabel!
    @IBOutlet weak var inputFieldDate3: UITextField!
    @IBOutlet weak var inputDate3: UITextField!
    @IBOutlet weak var fieldDatePicker: UIDatePicker!
    
    @IBOutlet weak var pickerPaletteView: UIView!
    @IBOutlet weak var doneButton: UIButton!

    @IBOutlet var checkboxesButtons: [UIButton]!
    @IBOutlet weak var outerTopConstraint: NSLayoutConstraint!
    
    private var keyboardAccessoryView: UIView? = nil

    var cpIndex: Int = 0
    var paletteVisible = false
    var fieldFlag = false
    var fieldDateFlag = false
    var checkboxFlag = false
    var radioFlag = false
 
    func loadCP(index: Int){
        
        let cp = CheckpointManager.sharedManager.checkpoints[index]
        
        self.titleLabel.text = cp.title
        
        self.descriptionLabel.text = cp.description
        
        
        
       
        
        if let moreInfo = cp.moreInfo {
         
            self.moreInfoButton.setTitle(moreInfo, for: .normal)
            
            
            self.moreInfoButton.isHidden = false
        } else {
            self.moreInfoButton.isHidden = true
        }
        
        let type = cp.entry.type
        
        switch type {
        case .FieldEntry:
            showStack(stack: fieldStackview)
            hideStack(stack: checkboxStackview)
            hideStack(stack: radioStackview)
            hideStack(stack: fieldDateStackview)
            self.fieldLabel1.text = cp.entry.instances[0].prompt
            self.fieldLabel2.text = cp.entry.instances[1].prompt
            self.fieldLabel3.text = cp.entry.instances[2].prompt
            resetFlags()
            fieldFlag = true
        
        case .CheckboxEntry:
            showStack(stack: checkboxStackview)
            hideStack(stack: fieldStackview)
            hideStack(stack: radioStackview)
            hideStack(stack: fieldDateStackview)
            resetFlags()
            checkboxFlag = true
            
            var checkboxIndex: Int = 0
            for checkbox in checkboxesButtons {
                checkbox.setTitle(cp.entry.instances[checkboxIndex].prompt, for: .normal)
                checkbox.setTitle(cp.entry.instances[checkboxIndex].prompt, for: .selected)
                checkboxIndex += 1
            }
            
        case .RadioEntry:
            showStack(stack: radioStackview)
            hideStack(stack: fieldStackview)
            hideStack(stack: checkboxStackview)
            hideStack(stack: fieldDateStackview)
            resetFlags()
            radioFlag = true
            var radiobuttonIndex: Int = 0
            
            for radio in radioButtons {
                print("The current Radio Button Index is", radiobuttonIndex)
                print(cp.entry.instances[radiobuttonIndex].prompt)
                radio.setTitle(cp.entry.instances[radiobuttonIndex].prompt, for: .normal)
                radio.setTitle(cp.entry.instances[radiobuttonIndex].prompt, for: .selected)
                print(radio.titleLabel)
                radiobuttonIndex += 1
            }
        
        case .FieldDateEntry:
            hideStack(stack: fieldStackview)
            hideStack(stack: checkboxStackview)
            hideStack(stack: radioStackview)
            showStack(stack: fieldDateStackview)
            self.fieldDateLabel1.text = cp.entry.instances[0].prompt
            self.fieldDateLabel2.text = cp.entry.instances[1].prompt
            self.fieldDateLabel3.text = cp.entry.instances[2].prompt
            resetFlags()
            fieldDateFlag = true

        }
        
        
    }
    func nextCP(){
        let maxCP = CheckpointManager.sharedManager.checkpoints.count
        if cpIndex < maxCP-1 {
            cpIndex = cpIndex + 1
            loadCP(index: cpIndex)
        }
    }
    
    
    
    @IBAction func handleSubmit(_ sender: UIButton) {
        if fieldFlag == true {
            let defaults = UserDefaults.standard
            defaults.set(inputField1.text, forKey: "fkey1")
            defaults.set(inputField2.text, forKey: "fkey2")
            defaults.set(inputField3.text, forKey: "fkey3")
            defaults.synchronize()
            
            let testField1 = defaults.object(forKey: "fkey1")
            let testField2 = defaults.object(forKey: "fkey2")
            let testField3 = defaults.object(forKey: "fkey3")
            
            print(testField1, testField2, testField3)
        }
        else if fieldDateFlag == true {
            let defaults = UserDefaults.standard
            defaults.set(inputFieldDate1.text, forKey: "fdfield1")
            defaults.set(inputDate1.text, forKey: "fddate1")
            defaults.set(inputFieldDate2.text, forKey: "fdfield2")
            defaults.set(inputDate2.text, forKey: "fddate2")
            defaults.set(inputFieldDate3.text, forKey: "fdfield3")
            defaults.set(inputDate3.text, forKey: "fddate3")
            defaults.synchronize()
            
            let testFDfield1 = defaults.object(forKey: "fdfield1")
            let testFDDate1 = defaults.object(forKey: "fdfield1")
            let testFDfield2 = defaults.object(forKey: "fdfield2")
            let testFDDate2 = defaults.object(forKey: "fdfield2")
            let testFDfield3 = defaults.object(forKey: "fdfield3")
            let testFDDate3 = defaults.object(forKey: "fdfield3")
            
            print(testFDfield1, testFDDate1, testFDfield2, testFDDate2, testFDfield3, testFDDate3)
        }
        else if checkboxFlag == true {
            let defaults = UserDefaults.standard
            var keyHolder: [String] = []
            for checkbox in checkboxesButtons{
                if checkbox.isSelected {
                    defaults.set(checkbox.titleLabel?.text, forKey: titleLabel.text! + (checkbox.titleLabel?.text!)!)
                    keyHolder.append(titleLabel.text! + (checkbox.titleLabel?.text!)!)
                }
            }
            defaults.synchronize()
            for key in keyHolder {
                print(defaults.object(forKey: key))
            }
        }
        else if radioFlag == true {
            let defaults = UserDefaults.standard
            for radiobtn in radioButtons {
                if radiobtn.isSelected {
                    defaults.set(radiobtn.titleLabel?.text, forKey: "radiobtnKey")
                }
            }
            defaults.synchronize()
            let testRadioBtn = defaults.object(forKey: (forKey: "radiobtnKey"))
            print(testRadioBtn)
        }
    }
    
    func prevCP(){
        if cpIndex > 0 {
            cpIndex = cpIndex - 1
            loadCP(index: cpIndex)
        }
    }
    
    func resetFlags(){
        fieldFlag = false
        fieldDateFlag = false
        checkboxFlag = false
        radioFlag = false
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Checkpoint"
        
        self.moreInfoButton.addTarget(self, action: #selector(showMoreInfo), for: .touchUpInside)
        
        self.NextButton.addTarget(self, action: #selector(nextCP), for: .touchUpInside)
        
        self.PrevButton.addTarget(self, action: #selector(prevCP), for: .touchUpInside)
        
        
        CheckpointManager.sharedManager.fetchJSON() { (success) in
            
            print("fetchJSON was successful: \(success)")
            
            
            self.loadCP(index: self.cpIndex)
            
       }
        
        self.keyboardAccessoryView = UIView(frame: CGRect(x:0.0, y:0.0, width:0.0, height:40.0))
        self.keyboardAccessoryView?.backgroundColor = UIColor.lightGray.withAlphaComponent(0.95)
        
        let doneBtn = UIButton(type: .system)
        doneBtn.translatesAutoresizingMaskIntoConstraints = false
        doneBtn.setTitle(NSLocalizedString("Done", comment: ""), for: .normal)
        doneBtn.addTarget(self, action: #selector(doneWithKeyboard(btn:)), for: .touchUpInside)
        self.keyboardAccessoryView?.addSubview(doneBtn)
        
        let views = ["doneBtn": doneBtn]
        var allConstraints = [NSLayoutConstraint]()
        allConstraints += NSLayoutConstraint.constraints(withVisualFormat: "V:|[doneBtn]|", options: [], metrics: nil, views: views)
        allConstraints += NSLayoutConstraint.constraints(withVisualFormat: "H:[doneBtn]-20-|", options: [], metrics: nil, views: views)
        NSLayoutConstraint.activate(allConstraints)
        
        for subview in self.fieldStackview.arrangedSubviews {
            if let textField = subview as? UITextField {
                textField.inputAccessoryView = keyboardAccessoryView
            }
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // hookup the keyboard show/hide notifications
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardDidShow(notification:)), name: Notification.Name.UIKeyboardDidShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(keyboardDidHide(notification:)), name: Notification.Name.UIKeyboardWillHide, object: nil)
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        // unhookup the keyboard show/hide notifications
        NotificationCenter.default.removeObserver(self, name: Notification.Name.UIKeyboardDidShow, object: nil)
        NotificationCenter.default.removeObserver(self, name: Notification.Name.UIKeyboardWillHide, object: nil)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        self.pickerPaletteView.frame = CGRect(x: 0, y: self.view.bounds.size.height, width: self.view.bounds.size.width, height: pickerPaletteView.frame.size.height)
    }
    
    private dynamic func keyboardDidShow(notification: NSNotification) {
        guard let userInfo = notification.userInfo, let r = userInfo[UIKeyboardFrameEndUserInfoKey] as? NSValue
            else { return }
        
        // get the active text field
        guard let textField = self.activeTextField() else {
            return
        }
        
        // get the height of the keyboard
        let kbHeight = r.cgRectValue.height
        
        // convert the text field bounds to the coordinates of the top level view (so they can be compared to the keyboard position)
        let textFieldBounds = textField.convert(textField.bounds, to: self.view)
        let textFieldBottom = textFieldBounds.maxY
        
        // get the top of the keyboard
        let kbTop = self.view.frame.maxY - kbHeight
        
        // see if we need to move the text field to avoid the keyboard
        if (textFieldBottom < kbTop)
        {
            return
        }
        
        // animate the moving of the text field by adjusting the top constraint of the outer stack view
        self.view.layoutIfNeeded()
        UIView.animate(withDuration: 0.3, animations: {
            let offset = textFieldBottom - kbTop
            self.outerTopConstraint.constant = -offset
            self.view.layoutIfNeeded()
        })
    }
    
    private dynamic func keyboardDidHide(notification: NSNotification) {
        
        // animate the moving back of the contents by resetting the top constraint of the outer stack view
        self.view.layoutIfNeeded()
        UIView.animate(withDuration: 0.3, animations: {
            self.outerTopConstraint.constant = 8
            self.view.layoutIfNeeded()
        })
    }
    
    private dynamic func doneWithKeyboard(btn: UIButton) {
        self.view.endEditing(true)
    }
    
    private func activeTextField() -> UITextField? {
        
        // if the text field stack is hidden then no active text field
        guard !self.fieldStackview.isHidden else {
            return nil
        }
        
        // ask each of the subviews of the text field stack view if it is the first responder
        for view in self.fieldStackview.arrangedSubviews {
            if view.isFirstResponder {
                return view as? UITextField
            }
        }
        
        // did not find any active text fields
        return nil
    }
    
    @IBAction func handleRadio(_ sender: UIButton) {
        
        for radio in radioButtons {
            radio.isSelected = false
        }
        
        sender.isSelected = true
        

    }
    
    @IBAction func handleCheckbox(_ sender: UIButton) {
        sender.isSelected = !sender.isSelected

    }
    
    @IBAction func donePressed(_ sender: UIButton) {
        self.pickerPaletteView.frame = CGRect(x: 0, y: self.view.bounds.size.height, width: self.view.bounds.size.width, height: pickerPaletteView.frame.size.height)
    }
    
//    @IBAction func fieldDateHandler(_ sender: AnyObject) {
//        UIView.animate(withDuration: 0.3) {
//            let top = (self.paletteVisible ? self.view.bounds.size.height : self.view.bounds.size.height - self.pickerPaletteView.frame.size.height);
//            self.pickerPaletteView.frame = CGRect(x: 0, y: top, width: self.view.bounds.size.width, height: self.pickerPaletteView.frame.size.height)
//            self.paletteVisible = !self.paletteVisible
//        }
//        sender.inputView = pickerPaletteView
//        pickerPaletteView.addTarget(self, action: #selector(ViewController.datePickerValueChanged), forControlEvents: UIControlEvents.ValueChanged)
//        
//    }
//    
//    func datePickerValueChanged(sender:UIDatePicker){
//        let dateFormatter = DateFormatter()
    
        
//    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func hideStack(stack: UIStackView){
        stack.isHidden = true
    }
    
    func showStack(stack: UIStackView){
        stack.isHidden = false
    }
    
    
    func showMoreInfo() {
        
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "webview") as! WebViewController
        vc.url = CheckpointManager.sharedManager.checkpoints[cpIndex].moreInfo!
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
